<div class="pagetitle" style="display: flex; justify-content: center; align-items: center;">
    <h1 style="font-size: 2.5rem;">
        {{ $slot}}
    </h1>
</div>