<section class="section">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            {{ $slot }}
        </div>
    </div>
</section>