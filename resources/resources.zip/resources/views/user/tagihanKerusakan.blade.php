<x-layout>
    <x-slot name="title">
        Laporan Kerusakan
    </x-slot>

    <div class="pagetitle">
        <h1>Tagihan</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="route('dashboard')">Home</a></li>
                <li class="breadcrumb-item">Users</li>
                <li class="breadcrumb-item active">Tagihan</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <!-- List tagihan yang dimiliki user -->
    <section class="section">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card recent-sales overflow-auto">
                    <div class="card-body">
                        <h5 class="card-title">List Tagihan Kerusakan</h5>
                        <div class="my-2 flex sm:flex-row flex-col">
                            <div class="block relative">
                            <table class="table table-borderless datatable table-hover">
                                <thead style="background-color: rgba(233, 239, 248, 0.5);">
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">ID Peminjaman</th>
                                        <th scope="col">Kerusakan</th>
                                        <th scope="col">Biaya Kerusakan</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($tagihan as $item)
                                    <tr>
                                        <th scope="row">{{ $loop->iteration }}</th>
                                        <td>{{ $item->laporan_kerusakan->detailPeminjaman->peminjaman->id_peminjaman }}</td>
                                        <td>{{ $item->laporan_kerusakan->deskripsi_kerusakan }}</td>
                                        <td>Rp{{ number_format($item->total_tagihan, 0, ',', '.') }} </td>
                                        <td>
                                            @if ($item->status == 'capture' || $item->status == 'settlement')
                                            <span class="badge bg-success">Lunas</span>
                                            @elseif ($item->status == 'pending')
                                            <span class="badge bg-warning">Menunggu Pembayaran</span>
                                            @else
                                            <span class="badge bg-danger">{{ $item->status }}</span>
                                            @endif
                                        </td>
                                        
                                        <td>
                                            @if ($item->status == 'capture' || $item->status == 'settlement')
                                            <button type="button" class="btn btn-success btn-sm" title="Tagihan Lunas">
                                                <i class="fas fa-check"></i>
                                                Lunas
                                            </button>
                                            @elseif ($item->payment_url != null)
                                            <a href="{{ $item->payment_url }}" target="_blank" class="btn btn-success btn-sm" title="Bayar Tagihan">
                                                <i class="fas fa-credit-card"></i>
                                                Bayar Tagihan
                                            </a>
                                            @elseif ($item->payment_url == null)
                                            <form action="{{ route('user.tagihan_kerusakan.bayar', $item->id) }}" method="POST">
                                                @csrf
                                                <button type="submit" class="btn btn-primary btn-sm" title="Buat Link Pembayaran">
                                                    <i class="fas fa-credit-card"></i>
                                                    Buat Link Pembayaran
                                                </button>
                                            </form>
                                            @else
                                            <button type="button" class="btn btn-danger btn-sm" title="Tagihan Dibatalkan">
                                                <i class="fas fa-times"></i>
                                                {{ $item->status }}
                                            </button>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-layout>