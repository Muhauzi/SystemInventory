<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Reminder</title>
</head>
<body>
<h1>Reminder: Upcoming Return Due</h1>
    <p>Dear User,</p>
    <p>This is a reminder that your loaned item <strong>Barang</strong> is due to be returned on <strong>{{ $data->tanggal_tenggat }}</strong>.</p>
    <p>Please return it on or before the due date.</p>
</body>
</html>